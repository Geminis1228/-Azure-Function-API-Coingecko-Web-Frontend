import logging
import json
import requests
import azure.functions as func

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    try:
        req_body = req.get_json()
    except ValueError:
        return func.HttpResponse("Invalid JSON", status_code=400)

    coin_id = req_body.get('coin')
    if not coin_id:
        return func.HttpResponse("Please pass a 'coin' in the JSON body", status_code=400)

    url = f"https://api.coingecko.com/api/v3/simple/price?ids={coin_id}&vs_currencies=usd,mxn"
    response = requests.get(url)
    if response.status_code != 200:
        return func.HttpResponse("Failed to fetch price from Coingecko", status_code=500)

    price_data = response.json()

    if coin_id not in price_data:
        return func.HttpResponse("Invalid coin ID", status_code=400)

    result = {
        'coin': coin_id,
        'usd': price_data[coin_id]['usd'],
        'mxn': price_data[coin_id]['mxn']
    }

    return func.HttpResponse(json.dumps(result), status_code=200, mimetype="application/json")
